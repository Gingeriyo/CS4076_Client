module com.mycompany.hellofx {
    requires javafx.controls;
    exports com.mycompany.hellofx;
}
